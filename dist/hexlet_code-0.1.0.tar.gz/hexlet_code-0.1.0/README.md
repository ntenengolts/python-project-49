### Hexlet tests and linter status:
[![Actions Status](https://github.com/ntenengolts/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ntenengolts/python-project-49/actions)

# My Project
[![Maintainability](https://api.codeclimate.com/v1/badges/e7cb024b471b83f27558/maintainability)](https://codeclimate.com/github/ntenengolts/python-project-49/maintainability)

#Demo
[![asciicast](https://asciinema.org/a/534b113b-3062-478e-933e-dda920911a1a.png)](https://asciinema.org/a/534b113b-3062-478e-933e-dda920911a1a)
